<?php

    include_once('vendor/autoload.php');
    use Moovly\SDK\Client\APIClient;
    use Moovly\SDK\Service\MoovlyService;
    use Moovly\SDK\Factory\ValueFactory;
    use Moovly\SDK\Factory\JobFactory;

    $clients = [
        ['name' => 'Bill Gates'],
        ['name' => 'Jeff Besos'],
        ['name' => 'Elon Musk'],
    ];
    
    $projectId = '892eb49c-48f1-4ab6-a0d5-934419ad6ffc';
    $accessToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJNb292bHkiLCJhdWQiOiJwZXJzb25hbC1hY2Nlc3MtdG9rZW5zIiwianRpIjoiNzAzYTk4ZjRiY2EwMzBiODc1ZDNiMjNjMmIxMTk5Nzg5MTRkMTJjMzRiZjE3OThjNDQ1NTRmYmU1Zjk5ZjQyZGM4NDMyM2E2MmNjMmZkMjMiLCJpYXQiOjE2Mjk0NDczMjQuNDc4NjYyLCJleHAiOjE2NjA5ODMzMjQuNDY4ODYsInN1YiI6ImYzZTgyZGFkLTAwYjYtMTFlYy1hYjYyLTBhOTFmOTZmODM2ZSIsInVzZXJfaWQiOjE1Mzk5MDUyOTEsInJvbGVzIjpbIlJPTEVfUEVSU09OQUxfQUNDRVNTX1RPS0VOIl19.22cYt5enmcgRz7uk-Z7beDP3LHoX9mN663RxdRi5b9fGV3yxKjJR9uFDGJ0LWvbRg8-EDlIBH5GHK6lqh3rY6ZKPvBhYeunhLWnyN_J9e-Qbm6tO-v6wVtzDpg4HNOZBa_19SlaG8KsYBnEgXN-VUYnXrOr3j14C_cRqPo24kK09t1TRkVu_rMWWRuKe-C0qjyCanabwWLTjbotshOJIEe1qDrLmWA1Gi8bEy7Xyv7nY37OBcP4eggSO96UPv_MYTgSbPz1VuS4YqRf97fVk3xhS6oz2hAsdrm-W47mAdFXkUFpLbGlPlgyHB9hTo9fVGbgyZ_k-PYtSXl28X2e97w';

    $client = new APIClient();

    $service = new MoovlyService($client, $accessToken);
    $project = $service->getProject($projectId);

    $template = $service->createTemplate($project);
    
    $values = [];

    // $nameVariable = $template->getVariables[0];
    
    // echo '<pre>';
    //     print_r($project->getId());
    // echo '</pre>';
    // die;

    foreach ($clients as $key => $client) {
        $values[] = ValueFactory::create(
            $key,
            $client['name'],
            [$template->getId() => sprintf('<p>%s</p>'), $client['name']]
        );
    }

    $settings = [
    'quality' => '480p',
    'create_render' => true,
    'create_project' => false,
    ];

    $job = JobFactory::create($values);

    $job->setTemplate($template);

    $job = $service->createJob($job, $options=[]);

    do {
        $job = $service->getJob($job->getId());
    } while ($job->getStatus() !== 'finished');

    $finishedUrls = array_map(function (Value $value) {
        return $value->getUrl();
    }, $job->getValues());

    echo 'Video urls ' . implode(', ', $finishedUrls);

    // https://developer.moovly.com/docs/guides/automator-php

?>